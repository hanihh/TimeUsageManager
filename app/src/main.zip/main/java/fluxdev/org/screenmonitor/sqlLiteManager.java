package fluxdev.org.screenmonitor;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by hiba on 5/10/15.
 */
public class sqlLiteManager extends SQLiteOpenHelper {
    SQLiteDatabase db;
    // Logcat tag
    private static final String LOG = "DatabaseHelper";
    // Database Version
    private static final int DATABASE_VERSION = 6;

    // Database Names
    private static final String DATABASE_NAME = "sessionDb";

    // Table Names
    protected static final String TABLE_SESSION = "session";
    protected static final String TABLE_APPS = "application";


    private static final String CREATE_TABLE_SESSION = "CREATE TABLE "
            + TABLE_SESSION + "("
            + "ID INTEGER PRIMARY KEY ,"
            + "start_date DATETIME,"
            + "end_date DATETIME NULL"
            + ")";

//    private static final String CREATE_TABLE_VOUCHER_HISTORY = "CREATE TABLE "
//            + TABLE_VOUCHER_HISTORY + "("
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_ID + " INTEGER PRIMARY KEY ,"
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_CODE + " TEXT NULL,"
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_ACTION + " INTEGER,"
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_ACTION_DATE+ " DATETIME NULL,"
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_PARAMETERS+ " TEXT,"
//            + Strings.VOUCHER_HISTORY_KEYS.KEY_RESULT+ " TEXT" + ")";


    private static final String CLEAR_TABLE_VOUCHER_HISTORY = "DELETE FROM "
            + TABLE_VOUCHER_HISTORY;

    public DBHelper(Context context) {
        super(context, VOUCHER_DATABASE_NAME, null, DATABASE_VERSION);
        db = getWritableDatabase();
        // TODO Auto-generated constructor stub
        Log.d("DB Helper", "constructor");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DB Helper", "onCreate_s");
        // TODO Auto-generated method stub
        db.execSQL(CREATE_TABLE_VOUCHER);
        db.execSQL(CREATE_TABLE_VOUCHER_HISTORY);
        Log.d("DB Helper", "onCreate_e");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        Log.d("DB Helper", "onUpgrade_s");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VOUCHER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VOUCHER_HISTORY);
        onCreate(db);
    }



    public void closeDB() {
        Log.d("DB Helper", "closeDb_s");
        SQLiteDatabase db = this.getReadableDatabase();
        if (db != null && db.isOpen())
            db.close();
    }

    protected String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}